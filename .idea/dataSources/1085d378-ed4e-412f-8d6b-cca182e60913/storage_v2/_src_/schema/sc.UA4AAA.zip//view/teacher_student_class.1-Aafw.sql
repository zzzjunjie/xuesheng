CREATE VIEW teacher_student_class AS
  SELECT
    `sc`.`t_student`.`s_name`       AS `s_name`,
    `sc`.`t_student`.`s_sex`        AS `s_sex`,
    `sc`.`t_student`.`s_department` AS `s_department`,
    `sc`.`t_student`.`s_class`      AS `s_class`,
    `sc`.`t_student`.`s_grade`      AS `s_grade`,
    `sc`.`t_class`.`c_name`         AS `c_name`,
    `sc`.`t_class`.`c_result`       AS `c_result`,
    `sc`.`t_student`.`s_id`         AS `s_id`
  FROM ((`sc`.`t_teacher`
    JOIN `sc`.`t_student` ON ((`sc`.`t_teacher`.`t_cnum` = `sc`.`t_student`.`s_cnum`))) JOIN `sc`.`t_class`
      ON (((`sc`.`t_student`.`s_id` = `sc`.`t_class`.`s_id`) AND (`sc`.`t_teacher`.`t_cid` = `sc`.`t_class`.`c_id`))));

