CREATE VIEW teacher_student AS
  SELECT
    `sc`.`t_student`.`s_id`         AS `s_id`,
    `sc`.`t_student`.`s_name`       AS `s_name`,
    `sc`.`t_student`.`s_sex`        AS `s_sex`,
    `sc`.`t_student`.`s_address`    AS `s_address`,
    `sc`.`t_student`.`s_department` AS `s_department`,
    `sc`.`t_student`.`s_class`      AS `s_class`,
    `sc`.`t_student`.`s_grade`      AS `s_grade`,
    `sc`.`t_student`.`s_phone`      AS `s_phone`,
    `sc`.`t_student`.`s_cnum`       AS `s_cnum`,
    `sc`.`t_teacher`.`t_cnum`       AS `t_cnum`
  FROM (`sc`.`t_student`
    JOIN `sc`.`t_teacher` ON ((`sc`.`t_teacher`.`t_cnum` = `sc`.`t_student`.`s_cnum`)))
  WHERE (`sc`.`t_teacher`.`t_cnum` = `sc`.`t_student`.`s_cnum`);

